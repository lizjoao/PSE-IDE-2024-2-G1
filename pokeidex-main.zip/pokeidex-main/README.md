# base-ps-2023-2
Repositório a ser usado de base para o processo seletivo 2032/2.
